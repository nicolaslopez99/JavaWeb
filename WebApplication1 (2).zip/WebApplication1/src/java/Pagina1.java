/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import logica.Capturar;

/**
 *
 * @author alejo
 */
public class Pagina1 extends HttpServlet{
       /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
     protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        
        Capturar p = new Capturar();
        response.setContentType("text/html;charset=UTF-8");
        String validar="radio1";
        
        p.setNombre(request.getParameter("nombre"));
        p.setApellido(request.getParameter("apellido"));
        p.setTelefono(request.getParameter("telefono"));
        p.setCorreo(request.getParameter("correo"));
        p.setDescripcion(request.getParameter("descripcion"));
        p.setEdad(request.getParameter("edad"));
        p.setNombre1(request.getParameter("nombre1"));
        p.setTelefono1(request.getParameter("telefono1"));
        p.setCorreo1(request.getParameter("correo1"));
        p.setDescripcion1(request.getParameter("descripcion1"));
        
        
        
        //p.setNombre(System.in(request.getParameter("nombre")));
        //p.setApellido(System.in(request.getParameter("apellido")));
        
        //s.setNumero1(Integer.parseInt(request.getParameter("numero1")));
        //s.setNumero2(Integer.parseInt(request.getParameter("numero2")));
        //s.su2mar();
        PrintWriter out = response.getWriter();
        try {
            out.println("<html>\n" +
"  <head>\n" +
"	<link href=\"hoja.css\" rel=\"stylesheet\" type=\"text/css\">\n" +
"	<script type=\"text/javascript\" src=\"ocultar.js\"></script>\n" +
"	<link href=\"hoja.css\" rel=\"stylesheet\" type=\"text/css\">\n" +
"  </head>\n" +
"  <body>\n" +
    p.mostrar(p.getNombre())+"\n"+
    p.mostrar(p.getApellido())+"\n"+
    p.mostrar(p.getCorreo())+"\n"+
    p.mostrar(p.getEdad())+"\n"+
    p.mostrar(p.getTelefono())+"\n"+
    p.mostrar(p.getDescripcion())+"\n"+
    p.mostrar(p.getNombre1())+"\n"+
    p.mostrar(p.getCorreo1())+"\n"+
    p.mostrar(p.getTelefono1())+"\n"+
    p.mostrar(p.getDescripcion1())+"\n"+
                    
"  </body>\n" +
"</html>");   
        } finally { 
            out.close();
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);

    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
}
