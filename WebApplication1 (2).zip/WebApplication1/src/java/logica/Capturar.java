/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logica;

/**
 *
 * @author Antonio
 */
public class Capturar {
    private String nombre;
    private String apellido;
    private String edad;
    private String telefono;
    private String correo;
    private String descripcion;
    private String nombre1;
    private String telefono1;
    private String descripcion1;
    private String correo1;
    

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public void setNombre1(String nombre11) {
        this.nombre1 = nombre1;
    }
    public void setTelefono1(String telefono1) {
        this.telefono1 = telefono1;
    }
    public void setDescripcion1(String descripcion1) {
        this.descripcion1 = descripcion1;
    }
    public void setCorreo1(String correo1) {
        this.correo1 = correo1;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public void setEdad(String edad) {
        this.edad = edad;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public String getEdad() {
       return edad;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }

    public String getDescripcion() {
        return descripcion;
    }
  
    public String getNombre1() {
        return nombre1;
    }
    public String getTelefono1() {
        return telefono1;
    }

    public String getCorreo1() {
        return correo1;
    }

    public String getDescripcion1() {
        return descripcion1;
    }
    public String mostrar(String prueba){
        if(prueba!= null){
            return prueba;
        } else{
            return " ";
        }
    }
    
}
