function mostrar(id) 
{
var Id, srcElement, targetElement;
var targetElement = document.getElementById(id);
if (targetElement.style.display == "none") {
targetElement.style.display = "";
} else {
targetElement.style.display = "none";
} 

}
function getVarsUrl(){
	    var url= location.search.replace("?", "");
	    var arrUrl = url.split("&");
	    var urlObj={};   
	    for(var i=0; i<arrUrl.length; i++){
		var x= arrUrl[i].split("=");
		urlObj[x[0]]=x[1]
	    }
	    return urlObj;
}
var misVariablesGet = getVarsUrl();  
 
document.write (misVariablesGet.nombre)
document.write (' ')
document.write (misVariablesGet.apellido)
document.write (' ')
document.write (misVariablesGet.edad)
document.write (' ')
document.write (misVariablesGet.telefono)
document.write (' ')
document.write (misVariablesGet.correo)
document.write (' ')
document.write (misVariablesGet.descripcion)
document.write (' ')
document.write (misVariablesGet.nombre1)
document.write (' ')
document.write (misVariablesGet.apellido1)
document.write (' ')
document.write (misVariablesGet.edad1)
document.write (' ')
document.write (misVariablesGet.telefono1)
document.write (' ')
document.write (misVariablesGet.correo1)
document.write (' ')
document.write (misVariablesGet.description1)
document.write (' ')
document.write (misVariablesGet.nombre2)
document.write (' ')
document.write (misVariablesGet.correo2)
document.write (' ')
document.write (misVariablesGet.description2)
document.write (' ')
document.write (misVariablesGet.telefono2)
document.write (' ')
document.write (misVariablesGet.nombre3)
document.write (' ')
document.write (misVariablesGet.correo3)
document.write (' ')
document.write (misVariablesGet.telefono3)
document.write (' ')
document.write (misVariablesGet.description3)

function validar(){
	    if(document.getElementById('nombre').value==""){
		alert('el nombre no puede ser vacio');
		return;
	    }
		if(document.getElementById('apellido').value==""){
		alert('el apellido no puede ser vacio');
		return;
	    }
		if(document.getElementById('edad').value==""){
		alert('la edad  no puede ser vacio');
		return;
	    }
		if(document.getElementById('semestre').value==""){
		alert('el semestre no puede ser vacio');
		return;
	    }
	    alert("Formulario completo");
}